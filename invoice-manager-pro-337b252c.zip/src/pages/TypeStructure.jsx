import React from 'react';
import { Card } from '@/components/ui/card';
import { Settings, MapPin, Package } from 'lucide-react';

export default function TypeStructure() {
  const aspectTypes = [
    {
      icon: Settings,
      name: 'Functional (F)',
      description: 'What it does',
      subtitle: 'Defines the function or purpose of the asset',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      icon: MapPin,
      name: 'Location (L)',
      description: 'Where it is',
      subtitle: 'Defines the physical location of the asset',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    },
    {
      icon: Package,
      name: 'Product (P)',
      description: 'What it is',
      subtitle: 'Defines the product or physical object',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    }
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Type Structure</h1>
        <p className="text-gray-600">
          Asset classification according to IEC 81346 & RDS-PS standards
        </p>
      </div>

      {/* Standards Info */}
      <Card className="p-6 mb-8 bg-gradient-to-r from-blue-50 to-teal-50 border-blue-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-3">About IEC 81346 & RDS-PS</h2>
        <p className="text-gray-700 mb-2">
          IEC 81346 is an international standard for structuring principles and reference designations 
          of systems and equipment. RDS-PS (Reference Designation System for Power Stations) is a 
          complementary classification system.
        </p>
        <p className="text-gray-700">
          The standard defines three main aspect types that can be used to classify and organize assets 
          in different ways based on their function, location, or product characteristics.
        </p>
      </Card>

      {/* Aspect Types */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {aspectTypes.map((type) => (
          <Card 
            key={type.name}
            className={`p-6 border-2 ${type.borderColor} ${type.bgColor} hover:shadow-lg transition-shadow`}
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${type.bgColor} border ${type.borderColor}`}>
                <type.icon className={`w-6 h-6 ${type.color}`} />
              </div>
              <div className="flex-1">
                <h3 className={`text-lg font-bold ${type.color} mb-1`}>{type.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{type.description}</p>
                <p className="text-xs text-gray-500">{type.subtitle}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Examples */}
      <Card className="p-6 bg-white border border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Example Asset Codes</h2>
        <div className="space-y-4">
          <div className="border-l-4 border-blue-500 pl-4">
            <div className="font-mono text-sm text-gray-600 mb-1">=PLT-01+CV-101</div>
            <div className="text-sm text-gray-900">
              <span className="font-semibold">Functional:</span> Control Valve in Plant 01
            </div>
          </div>
          <div className="border-l-4 border-red-500 pl-4">
            <div className="font-mono text-sm text-gray-600 mb-1">+SITE-01-AREA-A</div>
            <div className="text-sm text-gray-900">
              <span className="font-semibold">Location:</span> Physical location in Site 01, Area A
            </div>
          </div>
          <div className="border-l-4 border-orange-500 pl-4">
            <div className="font-mono text-sm text-gray-600 mb-1">=PLT-01+P-101</div>
            <div className="text-sm text-gray-900">
              <span className="font-semibold">Product:</span> Process Pump P-101 in Plant 01
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}