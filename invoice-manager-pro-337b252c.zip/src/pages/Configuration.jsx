import React from 'react';
import { Card } from '@/components/ui/card';
import { Settings, Database, Users, Shield } from 'lucide-react';

export default function Configuration() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Configuration</h1>
        <p className="text-gray-600">System settings and configuration options</p>
      </div>

      {/* Configuration Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-blue-50">
              <Settings className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">General Settings</h3>
              <p className="text-sm text-gray-600">
                Configure general application settings and preferences
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-green-50">
              <Database className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Data Management</h3>
              <p className="text-sm text-gray-600">
                Manage data import, export, and synchronization
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-purple-50">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">User Management</h3>
              <p className="text-sm text-gray-600">
                Manage users, roles, and permissions
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-orange-50">
              <Shield className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Security</h3>
              <p className="text-sm text-gray-600">
                Configure security settings and access controls
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}