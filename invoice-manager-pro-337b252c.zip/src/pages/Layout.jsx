
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from './utils';
import { 
  LayoutDashboard, 
  FolderOpen, 
  ChevronDown, 
  ChevronRight,
  Settings as SettingsIcon,
  BookOpen,
  FolderTree,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Layout({ children, currentPageName }) {
  const [assetRegisterOpen, setAssetRegisterOpen] = useState(true);
  const [masterRegisterOpen, setMasterRegisterOpen] = useState(false);
  const [projectRegisterOpen, setProjectRegisterOpen] = useState(false);

  const navItems = [
    { name: 'Dashboard', path: 'Dashboard', icon: LayoutDashboard },
  ];

  const assetRegisterItems = [
    { name: 'Functional', path: 'Functional', prefix: '=' },
    { name: 'Location', path: 'Location', prefix: '+' },
    { name: 'Product', path: 'Product', prefix: '—' },
    { name: 'Type Structure', path: 'TypeStructure', prefix: '%' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-52 bg-white border-r border-gray-200 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-16 h-16 rounded-full bg-[#1e3a5f] flex items-center justify-center">
              <BarChart3 className="w-8 h-8 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-2xl font-bold text-[#1e3a5f] tracking-tight">SAM</div>
              <div className="text-[9px] text-gray-500 uppercase tracking-wider mt-0.5">
                SØDERA ASSET MANAGEMENT
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          {/* Dashboard */}
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={createPageUrl(item.path)}
              className={cn(
                "flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg text-sm transition-colors",
                currentPageName === item.path
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-600 hover:bg-gray-50"
              )}
            >
              <item.icon className="w-4 h-4" />
              <span className="font-medium">{item.name}</span>
            </Link>
          ))}

          {/* Asset Register */}
          <div className="mt-2">
            <button
              onClick={() => setAssetRegisterOpen(!assetRegisterOpen)}
              className="flex items-center gap-2 px-4 py-2.5 mx-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 w-[calc(100%-1rem)] transition-colors"
            >
              <FolderOpen className="w-4 h-4" />
              <span className="font-medium flex-1 text-left">Asset Register</span>
              {assetRegisterOpen ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>
            {assetRegisterOpen && (
              <div className="mt-1 space-y-0.5">
                {assetRegisterItems.map((item) => (
                  <Link
                    key={item.path}
                    to={createPageUrl(item.path)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-2 mx-2 ml-6 rounded-lg text-sm transition-colors",
                      currentPageName === item.path
                        ? "bg-blue-50 text-blue-600"
                        : "text-gray-600 hover:bg-gray-50"
                    )}
                  >
                    <span className="text-xs opacity-60">{item.prefix}</span>
                    <span>{item.name}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Master Register */}
          <div className="mt-2">
            <button
              onClick={() => setMasterRegisterOpen(!masterRegisterOpen)}
              className="flex items-center gap-2 px-4 py-2.5 mx-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 w-[calc(100%-1rem)] transition-colors"
            >
              <BookOpen className="w-4 h-4" />
              <span className="font-medium flex-1 text-left">Master Register</span>
              {masterRegisterOpen ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Project Register */}
          <div className="mt-2">
            <button
              onClick={() => setProjectRegisterOpen(!projectRegisterOpen)}
              className="flex items-center gap-2 px-4 py-2.5 mx-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 w-[calc(100%-1rem)] transition-colors"
            >
              <FolderTree className="w-4 h-4" />
              <span className="font-medium flex-1 text-left">Project Register</span>
              {projectRegisterOpen ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Configuration */}
          <Link
            to={createPageUrl('Configuration')}
            className="flex items-center gap-3 px-4 py-2.5 mx-2 mt-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors"
          >
            <SettingsIcon className="w-4 h-4" />
            <span className="font-medium">Configuration</span>
          </Link>

          {/* Aspect Types */}
          <div className="mt-6 px-4">
            <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              ASPECT TYPES
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <SettingsIcon className="w-4 h-4 text-blue-500" />
                <div>
                  <div className="font-medium text-blue-600">Functional (F)</div>
                  <div className="text-xs text-gray-500">What it does</div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="w-4 h-4 rounded-full bg-red-500" />
                <div>
                  <div className="font-medium text-red-600">Location (L)</div>
                  <div className="text-xs text-gray-500">Where it is</div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="w-4 h-4 bg-orange-500 rounded" />
                <div>
                  <div className="font-medium text-orange-600">Product (P)</div>
                  <div className="text-xs text-gray-500">What it is</div>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 bg-[#1e3a5f]">
          <div className="text-white text-2xl font-bold tracking-wider">
            SØDERA
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
