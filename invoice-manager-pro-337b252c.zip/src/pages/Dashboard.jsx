import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Settings, MapPin, Package, Grid3x3 } from 'lucide-react';
import StatsCard from '../components/dashboard/StatsCard';
import QuickAccessCard from '../components/dashboard/QuickAccessCard';
import AssetListItem from '../components/dashboard/AssetListItem';

export default function Dashboard() {
  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 100)
  });

  const totalAssets = assets.length;
  const activeAssets = assets.filter(a => a.status === 'active').length;
  const functionalAssets = assets.filter(a => a.aspect_type === 'F').length;
  const locationAssets = assets.filter(a => a.aspect_type === 'L').length;
  const productAssets = assets.filter(a => a.aspect_type === 'P').length;

  const recentAssets = assets.slice(0, 5);

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">
          Welcome to SAM. Manage your asset register aligned to IEC 81346 & RDS-PS standards.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <StatsCard label="Total Assets" value={totalAssets} />
        <StatsCard label="Active Assets" value={activeAssets} color="text-teal-500" />
        <StatsCard label="Functional (F)" value={functionalAssets} color="text-blue-500" />
        <StatsCard label="Location (L)" value={locationAssets} color="text-purple-500" />
        <StatsCard label="Product (P)" value={productAssets} color="text-pink-500" />
      </div>

      {/* Quick Access */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <QuickAccessCard
            icon={Settings}
            title="Functional Assets"
            description="View assets by functional role"
            path="Functional"
            colorClass="text-blue-600"
            bgClass="border-blue-200 hover:border-blue-300 bg-blue-50/30"
          />
          <QuickAccessCard
            icon={MapPin}
            title="Location Assets"
            description="View assets by location"
            path="Location"
            colorClass="text-purple-600"
            bgClass="border-purple-200 hover:border-purple-300 bg-purple-50/30"
          />
          <QuickAccessCard
            icon={Package}
            title="Product Assets"
            description="View assets as products"
            path="Product"
            colorClass="text-red-600"
            bgClass="border-red-200 hover:border-red-300 bg-red-50/30"
          />
          <QuickAccessCard
            icon={Grid3x3}
            title="Type Structure"
            description="Manage asset types"
            path="TypeStructure"
            colorClass="text-teal-600"
            bgClass="border-teal-200 hover:border-teal-300 bg-teal-50/30"
          />
        </div>
      </div>

      {/* Recent Assets */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Recent Assets</h2>
        <div className="bg-white border border-gray-200 rounded-lg p-2">
          {isLoading ? (
            <div className="text-center py-8 text-gray-500">Loading assets...</div>
          ) : recentAssets.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No assets found</div>
          ) : (
            recentAssets.map((asset) => (
              <AssetListItem key={asset.id} asset={asset} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}