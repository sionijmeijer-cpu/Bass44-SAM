import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search } from 'lucide-react';
import AssetListItem from '../components/dashboard/AssetListItem';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function Product() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    status: 'active',
    description: '',
    asset_type: '',
    location: ''
  });

  const queryClient = useQueryClient();

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['product-assets'],
    queryFn: () => base44.entities.Asset.filter({ aspect_type: 'P' }, '-updated_date', 100)
  });

  const createAssetMutation = useMutation({
    mutationFn: (data) => base44.entities.Asset.create({ ...data, aspect_type: 'P' }),
    onSuccess: () => {
      queryClient.invalidateQueries(['product-assets']);
      queryClient.invalidateQueries(['assets']);
      setIsDialogOpen(false);
      setFormData({ name: '', code: '', status: 'active', description: '', asset_type: '', location: '' });
    }
  });

  const filteredAssets = assets.filter(asset =>
    asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    asset.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    createAssetMutation.mutate(formData);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Product Assets</h1>
        <p className="text-gray-600">View and manage assets as products</p>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search assets..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-red-600 hover:bg-red-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Product Asset
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Product Asset</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Asset Name</Label>
                <Input
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Process Pump P-101"
                />
              </div>
              <div>
                <Label>Asset Code</Label>
                <Input
                  required
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="e.g., =PLT-01+P-101"
                />
              </div>
              <div>
                <Label>Asset Type</Label>
                <Input
                  value={formData.asset_type}
                  onChange={(e) => setFormData({ ...formData, asset_type: e.target.value })}
                  placeholder="e.g., Pump, Motor, Exchanger"
                />
              </div>
              <div>
                <Label>Location</Label>
                <Input
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g., Plant 01"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Input
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Asset description"
                />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                Create Asset
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Assets List */}
      <div className="bg-white border border-gray-200 rounded-lg p-2">
        {isLoading ? (
          <div className="text-center py-12 text-gray-500">Loading assets...</div>
        ) : filteredAssets.length === 0 ? (
          <div className="text-center py-12 text-gray-500">No product assets found</div>
        ) : (
          filteredAssets.map((asset) => (
            <AssetListItem key={asset.id} asset={asset} />
          ))
        )}
      </div>
    </div>
  );
}