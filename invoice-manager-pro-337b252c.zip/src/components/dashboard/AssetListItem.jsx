import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export default function AssetListItem({ asset }) {
  const aspectColors = {
    F: 'bg-blue-50 text-blue-700 border-blue-200',
    L: 'bg-red-50 text-red-700 border-red-200',
    P: 'bg-orange-50 text-orange-700 border-orange-200'
  };

  return (
    <div className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0 hover:bg-gray-50 transition-colors px-4 rounded-lg">
      <div>
        <div className="font-semibold text-gray-900 mb-1">{asset.name}</div>
        <div className="text-xs text-gray-500 font-mono">{asset.code}</div>
      </div>
      <div className="flex items-center gap-3">
        <Badge 
          variant="outline" 
          className={cn("font-medium border", aspectColors[asset.aspect_type])}
        >
          {asset.aspect_type}
        </Badge>
        <Badge 
          className={cn(
            "font-medium",
            asset.status === 'active' 
              ? "bg-green-100 text-green-700 hover:bg-green-100" 
              : "bg-gray-100 text-gray-700 hover:bg-gray-100"
          )}
        >
          {asset.status.charAt(0).toUpperCase() + asset.status.slice(1)}
        </Badge>
      </div>
    </div>
  );
}