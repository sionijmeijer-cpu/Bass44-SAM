import React from 'react';
import { Card } from '@/components/ui/card';

export default function StatsCard({ label, value, color = 'text-gray-900' }) {
  return (
    <Card className="p-6 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
      <div className="text-sm text-gray-500 mb-2">{label}</div>
      <div className={`text-4xl font-bold ${color}`}>{value}</div>
    </Card>
  );
}