import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

export default function QuickAccessCard({ icon: Icon, title, description, path, colorClass, bgClass }) {
  return (
    <Link to={createPageUrl(path)}>
      <Card className={cn(
        "p-6 border-2 rounded-xl hover:shadow-lg transition-all duration-300 cursor-pointer group h-full",
        bgClass || "bg-white"
      )}>
        <div className="flex flex-col items-start gap-3">
          <div className={cn(
            "p-3 rounded-lg transition-transform group-hover:scale-110",
            bgClass?.includes('blue') ? 'bg-blue-100' : 
            bgClass?.includes('purple') ? 'bg-purple-100' :
            bgClass?.includes('red') ? 'bg-red-100' :
            bgClass?.includes('teal') ? 'bg-teal-100' :
            'bg-gray-100'
          )}>
            <Icon className={cn("w-6 h-6", colorClass)} />
          </div>
          <div>
            <h3 className={cn("font-semibold text-lg mb-1", colorClass)}>{title}</h3>
            <p className="text-sm text-gray-600">{description}</p>
          </div>
        </div>
      </Card>
    </Link>
  );
}